import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
/**
   A coin with a monetary value.
*/
public class Coin
{
	private double value;
	private String name;

   /**
      Constructs a coin.
      @param aValue the monetary value of the coin
      @param aName the name of the coin
   */
   public Coin(double aValue, String aName) 
   { 
      value = aValue; 
      name = aName;
   }
   public Coin() {
	   
   }


   /**
      Gets the coin value.
      @return the value
   */
   public double getValue() 
   {
      return value;
   }

   /**
      Gets the coin name.
      @return the name
   */
   public String getName() 
   {
      return name;
   }
   
   void read(Scanner in) throws NumberFormatException {
	  try {
		  name = in.next().trim();
		  //System.out.println(name + "Coin name");
		  value = Double.parseDouble(in.next());
	  }
	  catch(NumberFormatException exception) {
		  System.out.println("Fuckerman, you failed. Bad format");
	  }
  
	  
   }
   

	
}