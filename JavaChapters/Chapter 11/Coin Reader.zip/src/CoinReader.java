import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class CoinReader {
	public static void main(String args[]) {
		Scanner user = new Scanner(System.in);
		String inputFile = "";
		
		double total = 0;
		
		System.out.println("Please input the readable file name");
		inputFile = user.nextLine();
		try {	
			File input = new File(inputFile);
			Scanner in = new Scanner(input);
			//System.out.println(readFile(inputFile, in));
		
			ArrayList<Coin> array = readFile(inputFile, in);
			for(Coin element : array) {
				double cost = element.getValue();
				total = total + cost;
			}


		} catch(FileNotFoundException exception) {
			System.out.println("Fuckerman, bad file type. Each shit and die");
		} 
		System.out.println(total);	
		user.close();
	}
	static ArrayList<Coin> readFile(String inputFile, Scanner in) throws FileNotFoundException {
		
		ArrayList<Coin> cummy = new ArrayList<Coin>();
	
		while(in.hasNextLine()) {
			Coin cumerton = new Coin();
			cumerton.read(in);
			cummy.add(cumerton);
		}
		
		return cummy;
	}


}
