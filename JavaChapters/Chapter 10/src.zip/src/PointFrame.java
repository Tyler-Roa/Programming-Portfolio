import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Line2D;

import javax.swing.JComponent;

public class PointFrame extends JComponent {

	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		
	}
	
	public void placeDot(int x, int y) {
		//g2.drawOval(5, 5, 100, 100);
	}
}
